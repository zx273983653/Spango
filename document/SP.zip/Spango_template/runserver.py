from spango import runserver


if __name__ == '__main__':
    runserver.run()
