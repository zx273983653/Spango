class SpError(Exception):
    pass
