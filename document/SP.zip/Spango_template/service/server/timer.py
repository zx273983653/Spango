from spango.service.developer import timer

'''
服务端定时器，定时执行任务。
在配置文件中配置：server_timer = true 开启此功能。
不需要此功能建议不开启。
'''


def do():
    print('hello!')


def run():
    interval = 2  # 每次执行时间间隔
    timer.timer(interval, do)
