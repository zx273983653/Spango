from spango.urls import *

urls = [
    url('^/index22.html$', view='index22.html'),
    url('^/index33.html$', view='index33.html'),
]
