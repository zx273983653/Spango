1.需安装python3环境 推荐python3

2.将spango.zip模块解压缩，并导入python3环境中

详细说明请访问：http://www.deepspider.top